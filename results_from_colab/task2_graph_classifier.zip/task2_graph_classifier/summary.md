# task2_graph_classifier

## Scientific Framing

- Sparse detector hits are represented as graph nodes rather than treated as dense RGB-style pixels.
- Active channel order: Tracks, ECAL, HCAL.
- Each node stores normalized position, detector-specific intensities, and centroid-relative radius.
- Each edge stores deterministic spatial relations: delta_eta, delta_phi, distance, intensity difference.

## Config

- `batch_size`: `512`
- `dropout`: `0.4`
- `epochs`: `30`
- `hidden_dim`: `64`
- `knn_k`: `8`
- `lr`: `0.001`
- `max_events`: `None`
- `model_type`: `graphsage`
- `seed`: `42`

## Metrics

- `accuracy`: `0.705843`
- `baseline_test_accuracy`: `0.542757`
- `baseline_test_auc`: `0.564053`
- `baseline_test_f1`: `0.562119`
- `baseline_val_auc`: `0.579747`
- `f1`: `0.726764`
- `roc_auc`: `0.773594`
